#!/bin/bash
go build -o application
