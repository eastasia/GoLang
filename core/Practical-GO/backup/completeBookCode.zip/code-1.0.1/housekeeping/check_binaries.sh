find chap3 -type f -perm +0111 -print
