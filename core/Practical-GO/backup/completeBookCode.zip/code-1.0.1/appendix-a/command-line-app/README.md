# Command line client for package server

Built using:

- chap2/sub-cmd-arch
- chap3/pkg-register-data