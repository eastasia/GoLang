use package_server;

INSERT INTO users (username) VALUES ("joe_cool"), ("jane_doe"), ("go_fer"), ("gopher"), ("bill_bryson");