$env:LOG_LEVEL=1
$env:JAEGER_ADDR="http://127.0.0.1:14268"
$env:STATSD_ADDR="127.0.0.1:9125"
.\server.exe