# Using contexts for robustness in user input

- Listing 1.17 - listing6.go

