# Sub-command demo 

Listing 2.1 - main.go


