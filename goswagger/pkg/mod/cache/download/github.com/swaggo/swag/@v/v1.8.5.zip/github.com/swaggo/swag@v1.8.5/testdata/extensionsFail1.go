package main

// @title Swagger Example API
// @version 1.0
// @description This is a sample server Petstore server.
// @description It has a lot of beautiful features.
// @termsOfService http://swagger.io/terms/

// @securitydefinitions.oauth2.accessCode OAuth2AccessCode
// @tokenUrl https://example.com/oauth/token
// @authorizationurl https://example.com/oauth/authorize
// @scope.admin Grants read and write access to administrative information

// @x-google-endpoints ["name":"name.endpoints.environment.cloud.goog","allowCors":true}]
