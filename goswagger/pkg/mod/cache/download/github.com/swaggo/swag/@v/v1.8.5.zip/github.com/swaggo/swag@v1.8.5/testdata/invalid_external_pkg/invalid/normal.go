package invalid

func Foo() {

}
